import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { EventDomainFacade } from '@server/modules/event/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { EventApplicationEvent } from './event.application.event'
import { EventCreateDto } from './event.dto'

import { LocationDomainFacade } from '../../location/domain'

@Controller('/v1/locations')
export class EventByLocationController {
  constructor(
    private locationDomainFacade: LocationDomainFacade,

    private eventDomainFacade: EventDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/location/:locationId/events')
  async findManyLocationId(
    @Param('locationId') locationId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.locationDomainFacade.findOneByIdOrFail(locationId)

    const items = await this.eventDomainFacade.findManyByLocation(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/location/:locationId/events')
  async createByLocationId(
    @Param('locationId') locationId: string,
    @Body() body: EventCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, locationId }

    const item = await this.eventDomainFacade.create(valuesUpdated)

    await this.eventService.emit<EventApplicationEvent.EventCreated.Payload>(
      EventApplicationEvent.EventCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
