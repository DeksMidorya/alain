import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { EventDomainModule } from '../domain'
import { EventController } from './event.controller'

import { LocationDomainModule } from '../../../modules/location/domain'

import { EventByLocationController } from './eventByLocation.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    EventDomainModule,

    LocationDomainModule,
  ],
  controllers: [EventController, EventByLocationController],
  providers: [],
})
export class EventApplicationModule {}
