import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Location } from '../../../modules/location/domain'

import { Schedule } from '../../../modules/schedule/domain'

import { Attendance } from '../../../modules/attendance/domain'

@Entity()
export class Event {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  title?: string

  @Column({ nullable: true })
  description?: string

  @Column({ nullable: true })
  eventType?: string

  @Column({ nullable: true })
  startTime?: string

  @Column({ nullable: true })
  endTime?: string

  @Column({ nullable: true })
  locationId?: string

  @ManyToOne(() => Location, parent => parent.events)
  @JoinColumn({ name: 'locationId' })
  location?: Location

  @OneToMany(() => Schedule, child => child.event)
  schedules?: Schedule[]

  @OneToMany(() => Attendance, child => child.event)
  attendances?: Attendance[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
