import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { LocationDomainModule } from './location/domain'

import { EventDomainModule } from './event/domain'

import { OrganizationDomainModule } from './organization/domain'

import { MembershipDomainModule } from './membership/domain'

import { ScheduleDomainModule } from './schedule/domain'

import { AttendanceDomainModule } from './attendance/domain'

import { FeedbackDomainModule } from './feedback/domain'

import { AnnouncementDomainModule } from './announcement/domain'

import { BaptismweddingDomainModule } from './baptismwedding/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    LocationDomainModule,

    EventDomainModule,

    OrganizationDomainModule,

    MembershipDomainModule,

    ScheduleDomainModule,

    AttendanceDomainModule,

    FeedbackDomainModule,

    AnnouncementDomainModule,

    BaptismweddingDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
