import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { BaptismweddingDomainModule } from '../domain'
import { BaptismweddingController } from './baptismwedding.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { BaptismweddingByUserController } from './baptismweddingByUser.controller'

import { LocationDomainModule } from '../../../modules/location/domain'

import { BaptismweddingByLocationController } from './baptismweddingByLocation.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    BaptismweddingDomainModule,

    UserDomainModule,

    LocationDomainModule,
  ],
  controllers: [
    BaptismweddingController,

    BaptismweddingByUserController,

    BaptismweddingByLocationController,
  ],
  providers: [],
})
export class BaptismweddingApplicationModule {}
