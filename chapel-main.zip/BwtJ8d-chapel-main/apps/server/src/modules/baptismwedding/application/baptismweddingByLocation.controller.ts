import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { BaptismweddingDomainFacade } from '@server/modules/baptismwedding/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { BaptismweddingApplicationEvent } from './baptismwedding.application.event'
import { BaptismweddingCreateDto } from './baptismwedding.dto'

import { LocationDomainFacade } from '../../location/domain'

@Controller('/v1/locations')
export class BaptismweddingByLocationController {
  constructor(
    private locationDomainFacade: LocationDomainFacade,

    private baptismweddingDomainFacade: BaptismweddingDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/location/:locationId/baptismweddings')
  async findManyLocationId(
    @Param('locationId') locationId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.locationDomainFacade.findOneByIdOrFail(locationId)

    const items = await this.baptismweddingDomainFacade.findManyByLocation(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/location/:locationId/baptismweddings')
  async createByLocationId(
    @Param('locationId') locationId: string,
    @Body() body: BaptismweddingCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, locationId }

    const item = await this.baptismweddingDomainFacade.create(valuesUpdated)

    await this.eventService.emit<BaptismweddingApplicationEvent.BaptismweddingCreated.Payload>(
      BaptismweddingApplicationEvent.BaptismweddingCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
