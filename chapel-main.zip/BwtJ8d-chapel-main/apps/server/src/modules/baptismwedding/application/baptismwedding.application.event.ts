export namespace BaptismweddingApplicationEvent {
  export namespace BaptismweddingCreated {
    export const key = 'baptismwedding.application.baptismwedding.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
