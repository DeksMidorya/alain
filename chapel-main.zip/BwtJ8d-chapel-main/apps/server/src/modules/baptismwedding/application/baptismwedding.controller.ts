import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  Baptismwedding,
  BaptismweddingDomainFacade,
} from '@server/modules/baptismwedding/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { BaptismweddingApplicationEvent } from './baptismwedding.application.event'
import {
  BaptismweddingCreateDto,
  BaptismweddingUpdateDto,
} from './baptismwedding.dto'

@Controller('/v1/baptismweddings')
export class BaptismweddingController {
  constructor(
    private eventService: EventService,
    private baptismweddingDomainFacade: BaptismweddingDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.baptismweddingDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: BaptismweddingCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.baptismweddingDomainFacade.create(body)

    await this.eventService.emit<BaptismweddingApplicationEvent.BaptismweddingCreated.Payload>(
      BaptismweddingApplicationEvent.BaptismweddingCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:baptismweddingId')
  async findOne(
    @Param('baptismweddingId') baptismweddingId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.baptismweddingDomainFacade.findOneByIdOrFail(
      baptismweddingId,
      queryOptions,
    )

    return item
  }

  @Patch('/:baptismweddingId')
  async update(
    @Param('baptismweddingId') baptismweddingId: string,
    @Body() body: BaptismweddingUpdateDto,
  ) {
    const item =
      await this.baptismweddingDomainFacade.findOneByIdOrFail(baptismweddingId)

    const itemUpdated = await this.baptismweddingDomainFacade.update(
      item,
      body as Partial<Baptismwedding>,
    )
    return itemUpdated
  }

  @Delete('/:baptismweddingId')
  async delete(@Param('baptismweddingId') baptismweddingId: string) {
    const item =
      await this.baptismweddingDomainFacade.findOneByIdOrFail(baptismweddingId)

    await this.baptismweddingDomainFacade.delete(item)

    return item
  }
}
