import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { BaptismweddingDomainFacade } from './baptismwedding.domain.facade'
import { Baptismwedding } from './baptismwedding.model'

@Module({
  imports: [TypeOrmModule.forFeature([Baptismwedding]), DatabaseHelperModule],
  providers: [BaptismweddingDomainFacade, BaptismweddingDomainFacade],
  exports: [BaptismweddingDomainFacade],
})
export class BaptismweddingDomainModule {}
