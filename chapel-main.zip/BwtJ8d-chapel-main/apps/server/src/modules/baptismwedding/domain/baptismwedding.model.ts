import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Location } from '../../../modules/location/domain'

@Entity()
export class Baptismwedding {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  type?: string

  @Column({ nullable: true })
  scheduledDate?: string

  @Column({ nullable: true })
  userId?: string

  @ManyToOne(() => User, parent => parent.baptismweddings)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({ nullable: true })
  locationId?: string

  @ManyToOne(() => Location, parent => parent.baptismweddings)
  @JoinColumn({ name: 'locationId' })
  location?: Location

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
