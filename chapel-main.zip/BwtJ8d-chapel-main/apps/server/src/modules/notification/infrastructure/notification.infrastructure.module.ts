import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationLocationSubscriber } from './subscribers/notification.location.subscriber'

import { NotificationEventSubscriber } from './subscribers/notification.event.subscriber'

import { NotificationOrganizationSubscriber } from './subscribers/notification.organization.subscriber'

import { NotificationMembershipSubscriber } from './subscribers/notification.membership.subscriber'

import { NotificationScheduleSubscriber } from './subscribers/notification.schedule.subscriber'

import { NotificationAttendanceSubscriber } from './subscribers/notification.attendance.subscriber'

import { NotificationFeedbackSubscriber } from './subscribers/notification.feedback.subscriber'

import { NotificationAnnouncementSubscriber } from './subscribers/notification.announcement.subscriber'

import { NotificationBaptismweddingSubscriber } from './subscribers/notification.baptismwedding.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationLocationSubscriber,

    NotificationEventSubscriber,

    NotificationOrganizationSubscriber,

    NotificationMembershipSubscriber,

    NotificationScheduleSubscriber,

    NotificationAttendanceSubscriber,

    NotificationFeedbackSubscriber,

    NotificationAnnouncementSubscriber,

    NotificationBaptismweddingSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
