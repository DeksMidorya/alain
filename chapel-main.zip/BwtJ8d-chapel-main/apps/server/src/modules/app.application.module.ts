import { Module } from '@nestjs/common'
import { AuthenticationApplicationModule } from './authentication/application'
import { AuthorizationApplicationModule } from './authorization/application'
import { UserApplicationModule } from './user/application'

import { LocationApplicationModule } from './location/application'

import { EventApplicationModule } from './event/application'

import { OrganizationApplicationModule } from './organization/application'

import { MembershipApplicationModule } from './membership/application'

import { ScheduleApplicationModule } from './schedule/application'

import { AttendanceApplicationModule } from './attendance/application'

import { FeedbackApplicationModule } from './feedback/application'

import { AnnouncementApplicationModule } from './announcement/application'

import { BaptismweddingApplicationModule } from './baptismwedding/application'

import { AiApplicationModule } from './ai/application/ai.application.module'
import { NotificationApplicationModule } from './notification/application/notification.application.module'
import { UploadApplicationModule } from './upload/application/upload.application.module'

@Module({
  imports: [
    AuthenticationApplicationModule,
    UserApplicationModule,
    AuthorizationApplicationModule,
    NotificationApplicationModule,
    AiApplicationModule,
    UploadApplicationModule,

    LocationApplicationModule,

    EventApplicationModule,

    OrganizationApplicationModule,

    MembershipApplicationModule,

    ScheduleApplicationModule,

    AttendanceApplicationModule,

    FeedbackApplicationModule,

    AnnouncementApplicationModule,

    BaptismweddingApplicationModule,
  ],
  controllers: [],
  providers: [],
})
export class AppApplicationModule {}
