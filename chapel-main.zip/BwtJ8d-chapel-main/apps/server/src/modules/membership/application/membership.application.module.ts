import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { MembershipDomainModule } from '../domain'
import { MembershipController } from './membership.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { MembershipByUserController } from './membershipByUser.controller'

import { OrganizationDomainModule } from '../../../modules/organization/domain'

import { MembershipByOrganizationController } from './membershipByOrganization.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    MembershipDomainModule,

    UserDomainModule,

    OrganizationDomainModule,
  ],
  controllers: [
    MembershipController,

    MembershipByUserController,

    MembershipByOrganizationController,
  ],
  providers: [],
})
export class MembershipApplicationModule {}
