import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Event } from '../../../modules/event/domain'

import { Baptismwedding } from '../../../modules/baptismwedding/domain'

@Entity()
export class Location {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  name?: string

  @ColumnNumeric({ nullable: true, type: 'numeric' })
  capacity?: number

  @Column({ nullable: true })
  rulesAndRegulations?: string

  @OneToMany(() => Event, child => child.location)
  events?: Event[]

  @OneToMany(() => Baptismwedding, child => child.location)
  baptismweddings?: Baptismwedding[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
