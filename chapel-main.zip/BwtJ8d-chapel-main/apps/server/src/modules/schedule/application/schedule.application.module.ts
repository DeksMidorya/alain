import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ScheduleDomainModule } from '../domain'
import { ScheduleController } from './schedule.controller'

import { EventDomainModule } from '../../../modules/event/domain'

import { ScheduleByEventController } from './scheduleByEvent.controller'

import { OrganizationDomainModule } from '../../../modules/organization/domain'

import { ScheduleByOrganizationController } from './scheduleByOrganization.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ScheduleDomainModule,

    EventDomainModule,

    OrganizationDomainModule,
  ],
  controllers: [
    ScheduleController,

    ScheduleByEventController,

    ScheduleByOrganizationController,
  ],
  providers: [],
})
export class ScheduleApplicationModule {}
