import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Event } from '../../../modules/event/domain'

import { Organization } from '../../../modules/organization/domain'

@Entity()
export class Schedule {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  startTime?: string

  @Column({ nullable: true })
  endTime?: string

  @Column({ nullable: true })
  eventId?: string

  @ManyToOne(() => Event, parent => parent.schedules)
  @JoinColumn({ name: 'eventId' })
  event?: Event

  @Column({ nullable: true })
  organizationId?: string

  @ManyToOne(() => Organization, parent => parent.schedules)
  @JoinColumn({ name: 'organizationId' })
  organization?: Organization

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
