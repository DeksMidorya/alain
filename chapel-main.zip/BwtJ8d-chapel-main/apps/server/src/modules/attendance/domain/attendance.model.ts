import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Event } from '../../../modules/event/domain'

@Entity()
export class Attendance {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  timeIn?: string

  @Column({ nullable: true })
  timeOut?: string

  @Column({ nullable: true })
  qrCodeUrl?: string

  @Column({ nullable: true })
  userId?: string

  @ManyToOne(() => User, parent => parent.attendances)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({ nullable: true })
  eventId?: string

  @ManyToOne(() => Event, parent => parent.attendances)
  @JoinColumn({ name: 'eventId' })
  event?: Event

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
