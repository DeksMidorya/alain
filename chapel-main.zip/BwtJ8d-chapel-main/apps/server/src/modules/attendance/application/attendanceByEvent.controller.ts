import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { AttendanceDomainFacade } from '@server/modules/attendance/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { AttendanceApplicationEvent } from './attendance.application.event'
import { AttendanceCreateDto } from './attendance.dto'

import { EventDomainFacade } from '../../event/domain'

@Controller('/v1/events')
export class AttendanceByEventController {
  constructor(
    private eventDomainFacade: EventDomainFacade,

    private attendanceDomainFacade: AttendanceDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/event/:eventId/attendances')
  async findManyEventId(
    @Param('eventId') eventId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.eventDomainFacade.findOneByIdOrFail(eventId)

    const items = await this.attendanceDomainFacade.findManyByEvent(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/event/:eventId/attendances')
  async createByEventId(
    @Param('eventId') eventId: string,
    @Body() body: AttendanceCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, eventId }

    const item = await this.attendanceDomainFacade.create(valuesUpdated)

    await this.eventService.emit<AttendanceApplicationEvent.AttendanceCreated.Payload>(
      AttendanceApplicationEvent.AttendanceCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
