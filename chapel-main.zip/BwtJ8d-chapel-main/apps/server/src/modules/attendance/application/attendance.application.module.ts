import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { AttendanceDomainModule } from '../domain'
import { AttendanceController } from './attendance.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { AttendanceByUserController } from './attendanceByUser.controller'

import { EventDomainModule } from '../../../modules/event/domain'

import { AttendanceByEventController } from './attendanceByEvent.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    AttendanceDomainModule,

    UserDomainModule,

    EventDomainModule,
  ],
  controllers: [
    AttendanceController,

    AttendanceByUserController,

    AttendanceByEventController,
  ],
  providers: [],
})
export class AttendanceApplicationModule {}
