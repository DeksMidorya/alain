import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Baptismwedding } from './baptismwedding.model'

export class BaptismweddingApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Baptismwedding>,
  ): Promise<Baptismwedding[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/baptismweddings${buildOptions}`)
  }

  static findOne(
    baptismweddingId: string,
    queryOptions?: ApiHelper.QueryOptions<Baptismwedding>,
  ): Promise<Baptismwedding> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/baptismweddings/${baptismweddingId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<Baptismwedding>): Promise<Baptismwedding> {
    return HttpService.api.post(`/v1/baptismweddings`, values)
  }

  static updateOne(
    baptismweddingId: string,
    values: Partial<Baptismwedding>,
  ): Promise<Baptismwedding> {
    return HttpService.api.patch(
      `/v1/baptismweddings/${baptismweddingId}`,
      values,
    )
  }

  static deleteOne(baptismweddingId: string): Promise<void> {
    return HttpService.api.delete(`/v1/baptismweddings/${baptismweddingId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Baptismwedding>,
  ): Promise<Baptismwedding[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/baptismweddings${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Baptismwedding>,
  ): Promise<Baptismwedding> {
    return HttpService.api.post(
      `/v1/users/user/${userId}/baptismweddings`,
      values,
    )
  }

  static findManyByLocationId(
    locationId: string,
    queryOptions?: ApiHelper.QueryOptions<Baptismwedding>,
  ): Promise<Baptismwedding[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/locations/location/${locationId}/baptismweddings${buildOptions}`,
    )
  }

  static createOneByLocationId(
    locationId: string,
    values: Partial<Baptismwedding>,
  ): Promise<Baptismwedding> {
    return HttpService.api.post(
      `/v1/locations/location/${locationId}/baptismweddings`,
      values,
    )
  }
}
