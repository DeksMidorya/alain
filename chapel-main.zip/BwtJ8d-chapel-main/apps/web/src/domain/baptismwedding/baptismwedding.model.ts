import { User } from '../user'

import { Location } from '../location'

export class Baptismwedding {
  id: string

  type?: string

  scheduledDate?: string

  userId?: string

  user?: User

  locationId?: string

  location?: Location

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
