import { User } from '../user'

import { Event } from '../event'

export class Attendance {
  id: string

  timeIn?: string

  timeOut?: string

  qrCodeUrl?: string

  userId?: string

  user?: User

  eventId?: string

  event?: Event

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
