import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Location as LocationModel } from './location/location.model'

import { Event as EventModel } from './event/event.model'

import { Organization as OrganizationModel } from './organization/organization.model'

import { Membership as MembershipModel } from './membership/membership.model'

import { Schedule as ScheduleModel } from './schedule/schedule.model'

import { Attendance as AttendanceModel } from './attendance/attendance.model'

import { Feedback as FeedbackModel } from './feedback/feedback.model'

import { Announcement as AnnouncementModel } from './announcement/announcement.model'

import { Baptismwedding as BaptismweddingModel } from './baptismwedding/baptismwedding.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Location extends LocationModel {}

  export class Event extends EventModel {}

  export class Organization extends OrganizationModel {}

  export class Membership extends MembershipModel {}

  export class Schedule extends ScheduleModel {}

  export class Attendance extends AttendanceModel {}

  export class Feedback extends FeedbackModel {}

  export class Announcement extends AnnouncementModel {}

  export class Baptismwedding extends BaptismweddingModel {}
}
