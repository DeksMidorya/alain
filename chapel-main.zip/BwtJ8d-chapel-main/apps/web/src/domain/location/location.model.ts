import { Event } from '../event'

import { Baptismwedding } from '../baptismwedding'

export class Location {
  id: string

  name?: string

  capacity?: number

  rulesAndRegulations?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  events?: Event[]

  baptismweddings?: Baptismwedding[]
}
