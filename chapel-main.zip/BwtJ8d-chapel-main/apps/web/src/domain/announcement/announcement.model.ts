export class Announcement {
  id: string

  title?: string

  content?: string

  datePosted?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
