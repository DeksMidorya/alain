import { Notification } from '../notification'

import { Membership } from '../membership'

import { Attendance } from '../attendance'

import { Feedback } from '../feedback'

import { Baptismwedding } from '../baptismwedding'

export enum UserStatus {
  CREATED = 'CREATED',
  VERIFIED = 'VERIFIED',
}
export class User {
  id: string
  email: string
  status: UserStatus
  name: string
  pictureUrl: string
  password: string
  dateCreated: string
  dateUpdated: string
  notifications?: Notification[]

  memberships?: Membership[]

  attendances?: Attendance[]

  feedbacks?: Feedback[]

  baptismweddings?: Baptismwedding[]
}
