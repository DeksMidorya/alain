import { Location } from '../location'

import { Schedule } from '../schedule'

import { Attendance } from '../attendance'

export class Event {
  id: string

  title?: string

  description?: string

  eventType?: string

  startTime?: string

  endTime?: string

  locationId?: string

  location?: Location

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  schedules?: Schedule[]

  attendances?: Attendance[]
}
