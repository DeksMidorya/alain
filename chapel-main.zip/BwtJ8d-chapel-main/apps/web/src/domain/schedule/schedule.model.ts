import { Event } from '../event'

import { Organization } from '../organization'

export class Schedule {
  id: string

  startTime?: string

  endTime?: string

  eventId?: string

  event?: Event

  organizationId?: string

  organization?: Organization

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
