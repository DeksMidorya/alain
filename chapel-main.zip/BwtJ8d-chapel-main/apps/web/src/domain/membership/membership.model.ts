import { User } from '../user'

import { Organization } from '../organization'

export class Membership {
  id: string

  userId?: string

  user?: User

  organizationId?: string

  organization?: Organization

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
