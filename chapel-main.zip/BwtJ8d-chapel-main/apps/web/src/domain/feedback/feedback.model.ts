import { User } from '../user'

export class Feedback {
  id: string

  content?: string

  rating?: number

  userId?: string

  user?: User

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
