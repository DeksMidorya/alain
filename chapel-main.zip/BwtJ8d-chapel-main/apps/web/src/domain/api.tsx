import { AiApi } from './ai/ai.api'
import { AuthenticationApi } from './authentication/authentication.api'
import { AuthorizationApi } from './authorization/authorization.api'
import { UploadApi } from './upload/upload.api'

import { UserApi } from './user/user.api'

import { NotificationApi } from './notification/notification.api'

import { LocationApi } from './location/location.api'

import { EventApi } from './event/event.api'

import { OrganizationApi } from './organization/organization.api'

import { MembershipApi } from './membership/membership.api'

import { ScheduleApi } from './schedule/schedule.api'

import { AttendanceApi } from './attendance/attendance.api'

import { FeedbackApi } from './feedback/feedback.api'

import { AnnouncementApi } from './announcement/announcement.api'

import { BaptismweddingApi } from './baptismwedding/baptismwedding.api'

export namespace Api {
  export class Ai extends AiApi {}
  export class Authentication extends AuthenticationApi {}
  export class Authorization extends AuthorizationApi {}
  export class Upload extends UploadApi {}

  export class User extends UserApi {}

  export class Notification extends NotificationApi {}

  export class Location extends LocationApi {}

  export class Event extends EventApi {}

  export class Organization extends OrganizationApi {}

  export class Membership extends MembershipApi {}

  export class Schedule extends ScheduleApi {}

  export class Attendance extends AttendanceApi {}

  export class Feedback extends FeedbackApi {}

  export class Announcement extends AnnouncementApi {}

  export class Baptismwedding extends BaptismweddingApi {}
}
