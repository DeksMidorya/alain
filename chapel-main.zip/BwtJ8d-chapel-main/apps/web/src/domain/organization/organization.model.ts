import { Membership } from '../membership'

import { Schedule } from '../schedule'

export class Organization {
  id: string

  name?: string

  description?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  memberships?: Membership[]

  schedules?: Schedule[]
}
