import { RouterObject } from '@web/core/router'
import { useDesignSystem } from '@web/designSystem'
import { Model } from '@web/domain'
import { useAuthentication } from '@web/modules/authentication'
import { Col, Layout, Row } from 'antd'
import { useRouter } from 'next/navigation'
import { ReactNode } from 'react'
import { Leftbar } from './components/Leftbar'
import { Logo } from './components/Logo'
import { SubNavigation } from './components/SubNavigation'
import { Topbar } from './components/Topbar/index.layout'

interface Props {
  children: ReactNode
}

export const NavigationLayout: React.FC<Props> = ({ children }) => {
  const router = useRouter()

  const authentication = useAuthentication()
  const user = authentication?.user as Model.User

  const { isMobile } = useDesignSystem()

  const goTo = (url: string) => {
    router.push(url)
  }

  const goToUserPage = (url: string) => {
    router.push(url.replace(':id', user?.id))
  }

  const itemsLeftbar = [
    {
      key: '/home',
      label: 'Dashboard',
      onClick: () => goTo('/home'),
    },

    {
      key: '/announcements',
      label: 'Announcements',
      onClick: () => goTo('/announcements'),
    },

    {
      key: '/calendar',
      label: 'Church Calendar',
      onClick: () => goTo('/calendar'),
    },

    {
      key: '/attendance',
      label: 'Attendance Monitoring',
      onClick: () => goTo('/attendance'),
    },

    {
      key: '/scheduling/organizations',
      label: 'Organization Scheduling',
      onClick: () => goTo('/scheduling/organizations'),
    },

    {
      key: '/scheduling/chapel',
      label: 'Chapel Usage',
      onClick: () => goTo('/scheduling/chapel'),
    },

    {
      key: '/scheduling/events',
      label: 'Events Scheduling',
      onClick: () => goTo('/scheduling/events'),
    },

    {
      key: '/rules',
      label: 'Chapel Rules',
      onClick: () => goTo('/rules'),
    },

    {
      key: '/feedback',
      label: 'Feedback',
      onClick: () => goTo('/feedback'),
    },

    {
      key: '/hitmap',
      label: 'Hitmap',
      onClick: () => goTo('/hitmap'),
    },
  ]

  const itemsUser = []

  const itemsTopbar = []

  const itemsSubNavigation = [
    {
      key: '/home',
      label: 'Dashboard',
    },

    {
      key: '/announcements',
      label: 'Announcements',
    },

    {
      key: '/calendar',
      label: 'Church Calendar',
    },

    {
      key: '/attendance',
      label: 'Attendance Monitoring',
    },

    {
      key: '/scheduling/organizations',
      label: 'Organization Scheduling',
    },

    {
      key: '/scheduling/chapel',
      label: 'Chapel Usage',
    },

    {
      key: '/scheduling/events',
      label: 'Events Scheduling',
    },

    {
      key: '/rules',
      label: 'Chapel Rules',
    },

    {
      key: '/feedback',
      label: 'Feedback',
    },

    {
      key: '/hitmap',
      label: 'Hitmap',
    },
  ]

  const itemsMobile = [
    {
      key: 'profile',
      label: 'Profile',
      onClick: () => goTo(RouterObject.route.PROFILE),
    },
    {
      key: 'notifications',
      label: 'Notifications',
      onClick: () => goTo(RouterObject.route.NOTIFICATIONS),
    },
    ...itemsTopbar,
    ...itemsLeftbar,
  ]

  const isLeftbar = itemsLeftbar.length > 0 && !isMobile

  return (
    <>
      <Layout>
        <Row
          style={{
            height: '100vh',
            width: '100vw',
          }}
        >
          {isLeftbar && (
            <Col>
              <Leftbar
                items={itemsLeftbar}
                itemsUser={itemsUser}
                logo={<Logo className="m-2" />}
              />
            </Col>
          )}

          <Col
            style={{
              flex: 1,
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
            }}
          >
            <Topbar
              isMobile={isMobile}
              items={itemsTopbar}
              itemsMobile={itemsMobile}
              logo={!isLeftbar && <Logo width={40} height={40} />}
            />

            <Col
              style={{
                flex: 1,
                overflowY: 'auto',
                overflowX: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <SubNavigation items={itemsSubNavigation} />

              {children}
            </Col>
          </Col>
        </Row>
      </Layout>
    </>
  )
}
