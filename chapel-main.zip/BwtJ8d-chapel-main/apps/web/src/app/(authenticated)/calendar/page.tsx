'use client'

import { useEffect, useState } from 'react'
import {
  Button,
  Col,
  Row,
  Table,
  Typography,
  Modal,
  Form,
  Input,
  DatePicker,
  Select,
  Space,
  notification,
} from 'antd'
import { PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ChurchCalendarPage() {
  const [events, setEvents] = useState([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [form] = Form.useForm()
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const eventsFound = await Api.Event.findMany({ includes: ['location'] })
        setEvents(eventsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch events', { variant: 'error' })
      }
    }

    fetchEvents()
  }, [])

  const handleAddEvent = async values => {
    try {
      const formattedValues = {
        ...values,
        startTime: values.timeRange[0].toISOString(),
        endTime: values.timeRange[1].toISOString(),
      }
      await Api.Event.createOneByLocationId(values.locationId, formattedValues)
      enqueueSnackbar('Event added successfully', { variant: 'success' })
      setIsModalVisible(false)
      form.resetFields()
    } catch (error) {
      enqueueSnackbar('Failed to add event', { variant: 'error' })
    }
  }

  const columns = [
    {
      title: 'Title',
      dataIndex: 'title',
      key: 'title',
    },
    {
      title: 'Start Time',
      dataIndex: 'startTime',
      key: 'startTime',
      render: text => dayjs(text).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'End Time',
      dataIndex: 'endTime',
      key: 'endTime',
      render: text => dayjs(text).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'Location',
      dataIndex: 'location',
      key: 'location',
      render: location => location?.name,
    },
  ]

  const showModal = () => {
    setIsModalVisible(true)
  }

  const handleCancel = () => {
    setIsModalVisible(false)
    form.resetFields()
  }

  return (
    <PageLayout layout="full-width">
      <Title level={2}>Church Event Calendar</Title>
      <Text>Manage and view all church-related events and schedules.</Text>
      <Button
        type="primary"
        icon={<PlusOutlined />}
        onClick={showModal}
        style={{ marginBottom: 16 }}
      >
        Add Event
      </Button>
      <Table dataSource={events} columns={columns} rowKey="id" />
      <Modal
        title="Add New Event"
        visible={isModalVisible}
        onCancel={handleCancel}
        footer={null}
      >
        <Form form={form} layout="vertical" onFinish={handleAddEvent}>
          <Form.Item
            name="title"
            label="Event Title"
            rules={[
              {
                required: true,
                message: 'Please input the title of the event!',
              },
            ]}
          >
            <Input />
          </Form.Item>
          <Form.Item name="description" label="Description">
            <Input.TextArea />
          </Form.Item>
          <Form.Item
            name="timeRange"
            label="Time Range"
            rules={[
              {
                required: true,
                message: 'Please select the time range for the event!',
              },
            ]}
          >
            <DatePicker.RangePicker showTime />
          </Form.Item>
          <Form.Item
            name="locationId"
            label="Location"
            rules={[{ required: true, message: 'Please select the location!' }]}
          >
            <Select placeholder="Select a location">
              {/* Assuming locations are fetched and stored similarly to events */}
              {/* {locations.map(location => <Option value={location.id}>{location.name}</Option>)} */}
            </Select>
          </Form.Item>
          <Form.Item>
            <Space>
              <Button onClick={handleCancel}>Cancel</Button>
              <Button type="primary" htmlType="submit">
                Submit
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </PageLayout>
  )
}
