'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Col, Row, Space, Button } from 'antd'
import { HomeOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function RulesandRegulationsPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const [rules, setRules] = useState<string>('')

  useEffect(() => {
    const fetchRules = async () => {
      try {
        const locationData = await Api.Location.find({ includes: ['events'] })
        const chapelRules = locationData?.find(
          loc => loc.name === 'Chapel',
        )?.rulesAndRegulations
        if (chapelRules) {
          setRules(chapelRules)
        } else {
          enqueueSnackbar('No rules found for the Chapel.', { variant: 'info' })
        }
      } catch (error) {
        enqueueSnackbar('Failed to fetch rules and regulations.', {
          variant: 'error',
        })
      }
    }

    fetchRules()
  }, [])

  return (
    <PageLayout layout="full-width">
      <Space direction="vertical" size="large" style={{ width: '100%' }}>
        <Title level={2}>Chapel Rules and Regulations</Title>
        <Text>
          This page lists all the rules and regulations that members must follow
          while using the chapel facilities.
        </Text>
        <Row justify="center">
          <Col xs={24} sm={16} md={12}>
            <Card>
              <Text>{rules || 'Loading rules...'}</Text>
            </Card>
          </Col>
        </Row>
        <Button
          type="primary"
          icon={<HomeOutlined />}
          onClick={() => router.push('/home')}
        >
          Return to Home
        </Button>
      </Space>
    </PageLayout>
  )
}
