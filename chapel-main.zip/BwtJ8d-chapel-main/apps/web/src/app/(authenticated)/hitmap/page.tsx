'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Row, Col, Spin } from 'antd'
import { EnvironmentOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HitmapPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const [locations, setLocations] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const locationsFound = await Api.Location.findMany({
          includes: ['events', 'events.attendances'],
        })
        setLocations(locationsFound)
        setLoading(false)
      } catch (error) {
        enqueueSnackbar('Failed to fetch locations', { variant: 'error' })
        setLoading(false)
      }
    }

    fetchLocations()
  }, [])

  const handleCardClick = locationId => {
    router.push(`/location/${locationId}`)
  }

  return (
    <PageLayout layout="full-width">
      <Title level={2}>
        <EnvironmentOutlined /> Church Location Usage and Activity Density
      </Title>
      <Text type="secondary">
        Explore the usage intensity of different church locations based on
        scheduled events and attendance.
      </Text>
      {loading ? (
        <Spin size="large" />
      ) : (
        <Row gutter={[16, 16]} style={{ marginTop: 20 }}>
          {locations?.map(location => (
            <Col key={location.id} xs={24} sm={12} md={8} lg={6} xl={4}>
              <Card
                hoverable
                title={location.name}
                onClick={() => handleCardClick(location.id)}
              >
                <p>Capacity: {location.capacity}</p>
                <p>Events Scheduled: {location.events?.length}</p>
                <p>
                  Total Attendances:{' '}
                  {location.events?.reduce(
                    (acc, event) => acc + (event.attendances?.length || 0),
                    0,
                  )}
                </p>
                <p>
                  Last Updated:{' '}
                  {dayjs(location.dateUpdated).format('DD MMM YYYY')}
                </p>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </PageLayout>
  )
}
