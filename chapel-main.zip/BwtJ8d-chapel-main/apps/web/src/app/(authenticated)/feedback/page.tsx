'use client'

import { Button, Form, Input, Rate, Typography } from 'antd'
import { SmileOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function FeedbackPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [form] = Form.useForm()

  const handleSubmit = async (values: { content: string; rating: number }) => {
    try {
      if (!userId) {
        enqueueSnackbar('User not authenticated', { variant: 'error' })
        return
      }
      const feedback = await Api.Feedback.createOneByUserId(userId, {
        content: values.content,
        rating: values.rating,
        userId: userId,
      })
      enqueueSnackbar('Feedback submitted successfully', { variant: 'success' })
      form.resetFields()
    } catch (error) {
      enqueueSnackbar('Failed to submit feedback', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: '600px', margin: '0 auto' }}>
        <Title level={2}>
          <SmileOutlined /> Submit Your Feedback
        </Title>
        <Text>Please share your experience with us.</Text>
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          style={{ marginTop: '20px' }}
        >
          <Form.Item
            name="rating"
            label="Rating"
            rules={[
              { required: true, message: 'Please rate your experience!' },
            ]}
          >
            <Rate />
          </Form.Item>
          <Form.Item
            name="content"
            label="Feedback"
            rules={[{ required: true, message: 'Please enter your feedback!' }]}
          >
            <Input.TextArea rows={4} />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </div>
    </PageLayout>
  )
}
