'use client'

import { useEffect, useState } from 'react'
import {
  Typography,
  Table,
  Button,
  Modal,
  Form,
  Input,
  DatePicker,
  Select,
} from 'antd'
import { PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function AttendanceMonitoringPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const [events, setEvents] = useState([])
  const [attendances, setAttendances] = useState([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [selectedEventId, setSelectedEventId] = useState(null)

  useEffect(() => {
    fetchEvents()
  }, [])

  const fetchEvents = async () => {
    try {
      const eventsFound = await Api.Event.findMany({ includes: ['location'] })
      setEvents(eventsFound)
    } catch (error) {
      enqueueSnackbar('Failed to fetch events', { variant: 'error' })
    }
  }

  const fetchAttendances = async eventId => {
    try {
      const attendancesFound = await Api.Attendance.findManyByEventId(eventId, {
        includes: ['user'],
      })
      setAttendances(attendancesFound)
    } catch (error) {
      enqueueSnackbar('Failed to fetch attendances', { variant: 'error' })
    }
  }

  const handleEventSelect = eventId => {
    setSelectedEventId(eventId)
    fetchAttendances(eventId)
  }

  const showModal = () => {
    setIsModalVisible(true)
  }

  const handleOk = () => {
    setIsModalVisible(false)
  }

  const handleCancel = () => {
    setIsModalVisible(false)
  }

  const columns = [
    {
      title: 'Name',
      dataIndex: ['user', 'name'],
      key: 'name',
    },
    {
      title: 'Time In',
      dataIndex: 'timeIn',
      key: 'timeIn',
      render: text => dayjs(text).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: 'Time Out',
      dataIndex: 'timeOut',
      key: 'timeOut',
      render: text => dayjs(text).format('YYYY-MM-DD HH:mm:ss'),
    },
  ]

  return (
    <PageLayout layout="full-width">
      <Title>Attendance Monitoring</Title>
      <Text>Select an event to view attendance.</Text>
      <Select
        style={{ width: 200, marginBottom: 20 }}
        placeholder="Select an event"
        onChange={handleEventSelect}
      >
        {events.map(event => (
          <Option key={event.id} value={event.id}>
            {event.title}
          </Option>
        ))}
      </Select>
      <Button type="primary" icon={<PlusOutlined />} onClick={showModal}>
        Add Attendance
      </Button>
      <Table dataSource={attendances} columns={columns} rowKey="id" />

      <Modal
        title="Add Attendance"
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <Form layout="vertical">
          <Form.Item label="Time In">
            <DatePicker showTime />
          </Form.Item>
          <Form.Item label="Time Out">
            <DatePicker showTime />
          </Form.Item>
        </Form>
      </Modal>
    </PageLayout>
  )
}
