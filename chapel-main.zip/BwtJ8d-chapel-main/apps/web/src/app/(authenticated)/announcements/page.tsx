'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Row, Col, Spin } from 'antd'
import { ClockCircleOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function AnnouncementsPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const { enqueueSnackbar } = useSnackbar()
  const [announcements, setAnnouncements] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchAnnouncements = async () => {
      try {
        const data = await Api.Announcement.findMany()
        setAnnouncements(data)
        setLoading(false)
      } catch (error) {
        enqueueSnackbar('Failed to fetch announcements', { variant: 'error' })
        setLoading(false)
      }
    }

    fetchAnnouncements()
  }, [])

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
        <Title level={2}>Church Community Announcements</Title>
        <Text type="secondary">
          Stay updated with the latest happenings and events in our church
          community.
        </Text>
        <Row gutter={[16, 16]} style={{ marginTop: '20px' }}>
          {loading ? (
            <Spin size="large" />
          ) : (
            announcements?.map(announcement => (
              <Col xs={24} sm={12} md={8} lg={6} key={announcement.id}>
                <Card
                  title={announcement.title}
                  bordered={false}
                  hoverable
                  onClick={() =>
                    router.push(`/announcements/${announcement.id}`)
                  }
                >
                  <Text>{announcement.content}</Text>
                  <div style={{ marginTop: '10px' }}>
                    <ClockCircleOutlined style={{ marginRight: '5px' }} />
                    <Text type="secondary">
                      Posted on{' '}
                      {dayjs(announcement.datePosted).format('MMMM D, YYYY')}
                    </Text>
                  </div>
                </Card>
              </Col>
            ))
          )}
        </Row>
      </div>
    </PageLayout>
  )
}
