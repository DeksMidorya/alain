'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Row, Col, List, Avatar } from 'antd'
import {
  CalendarOutlined,
  NotificationOutlined,
  MessageOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [events, setEvents] = useState<Model.Event[]>([])
  const [announcements, setAnnouncements] = useState<Model.Announcement[]>([])
  const [notifications, setNotifications] = useState<Model.Notification[]>([])

  useEffect(() => {
    if (!userId) {
      enqueueSnackbar('User ID is missing', { variant: 'error' })
      return
    }

    const fetchData = async () => {
      try {
        const eventsData = await Api.Event.findMany({ includes: ['location'] })
        setEvents(eventsData)

        const announcementsData = await Api.Announcement.findMany()
        setAnnouncements(announcementsData)

        const notificationsData =
          await Api.Notification.findManyByUserId(userId)
        setNotifications(notificationsData)
      } catch (error) {
        enqueueSnackbar('Failed to fetch data', { variant: 'error' })
      }
    }

    fetchData()
  }, [userId])

  return (
    <PageLayout layout="full-width">
      <Title level={2}>Dashboard</Title>
      <Text>
        Welcome to your FaithCounts dashboard. Here's what's happening:
      </Text>

      <Row gutter={16} style={{ marginTop: 20 }}>
        <Col xs={24} sm={12} md={8}>
          <Card
            title="Upcoming Events"
            bordered={false}
            extra={
              <a href="#" onClick={() => router.push('/calendar')}>
                More
              </a>
            }
          >
            <List
              itemLayout="horizontal"
              dataSource={events}
              renderItem={event => (
                <List.Item>
                  <List.Item.Meta
                    avatar={<Avatar icon={<CalendarOutlined />} />}
                    title={
                      <a href="#" onClick={() => router.push('/calendar')}>
                        {event.title}
                      </a>
                    }
                    description={dayjs(event.startTime).format(
                      'D MMM YYYY h:mm A',
                    )}
                  />
                </List.Item>
              )}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card
            title="Recent Announcements"
            bordered={false}
            extra={
              <a href="#" onClick={() => router.push('/announcements')}>
                More
              </a>
            }
          >
            <List
              itemLayout="horizontal"
              dataSource={announcements}
              renderItem={announcement => (
                <List.Item>
                  <List.Item.Meta
                    avatar={<Avatar icon={<NotificationOutlined />} />}
                    title={
                      <a href="#" onClick={() => router.push('/announcements')}>
                        {announcement.title}
                      </a>
                    }
                    description={dayjs(announcement.datePosted).format(
                      'D MMM YYYY',
                    )}
                  />
                </List.Item>
              )}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card
            title="Notifications"
            bordered={false}
            extra={
              <a href="#" onClick={() => router.push('/home')}>
                More
              </a>
            }
          >
            <List
              itemLayout="horizontal"
              dataSource={notifications}
              renderItem={notification => (
                <List.Item>
                  <List.Item.Meta
                    avatar={<Avatar icon={<MessageOutlined />} />}
                    title={
                      <a href={notification.redirectUrl || '#'}>
                        {notification.title}
                      </a>
                    }
                    description={notification.message}
                  />
                </List.Item>
              )}
            />
          </Card>
        </Col>
      </Row>
    </PageLayout>
  )
}
