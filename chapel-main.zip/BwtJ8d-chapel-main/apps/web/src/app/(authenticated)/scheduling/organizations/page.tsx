'use client'

import { useEffect, useState } from 'react'
import {
  Typography,
  Table,
  Button,
  Space,
  Modal,
  Form,
  Input,
  DatePicker,
  Select,
} from 'antd'
import { PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function OrganizationSchedulingPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const { enqueueSnackbar } = useSnackbar()
  const [organizations, setOrganizations] = useState([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [currentOrgId, setCurrentOrgId] = useState(null)
  const [form] = Form.useForm()

  useEffect(() => {
    if (!authentication.isAuthenticated) {
      router.push('/home')
      return
    }

    const fetchOrganizations = async () => {
      try {
        const data = await Api.Organization.findMany({
          includes: ['schedules'],
        })
        setOrganizations(data)
      } catch (error) {
        enqueueSnackbar('Failed to fetch organizations', { variant: 'error' })
      }
    }

    fetchOrganizations()
  }, [authentication.isAuthenticated, router])

  const showAddScheduleModal = orgId => {
    setCurrentOrgId(orgId)
    setIsModalVisible(true)
  }

  const handleAddSchedule = async values => {
    try {
      await Api.Schedule.createOneByOrganizationId(currentOrgId, {
        startTime: values.startTime.toISOString(),
        endTime: values.endTime.toISOString(),
        eventId: values.eventId,
      })
      enqueueSnackbar('Schedule added successfully', { variant: 'success' })
      setIsModalVisible(false)
      form.resetFields()
    } catch (error) {
      enqueueSnackbar('Failed to add schedule', { variant: 'error' })
    }
  }

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Schedules',
      dataIndex: 'schedules',
      key: 'schedules',
      render: schedules => (
        <ul>
          {schedules?.map(schedule => (
            <li key={schedule.id}>
              {dayjs(schedule.startTime).format('YYYY-MM-DD HH:mm')} -{' '}
              {dayjs(schedule.endTime).format('YYYY-MM-DD HH:mm')}
            </li>
          ))}
        </ul>
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          <Button
            onClick={() => showAddScheduleModal(record.id)}
            icon={<PlusOutlined />}
            type="primary"
          >
            Add Schedule
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="full-width">
      <Title level={2}>Organization Scheduling</Title>
      <Text>Manage and view schedules for various church organizations.</Text>
      <Table dataSource={organizations} columns={columns} rowKey="id" />

      <Modal
        title="Add New Schedule"
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
      >
        <Form form={form} onFinish={handleAddSchedule}>
          <Form.Item
            name="startTime"
            label="Start Time"
            rules={[{ required: true }]}
          >
            <DatePicker showTime />
          </Form.Item>
          <Form.Item
            name="endTime"
            label="End Time"
            rules={[{ required: true }]}
          >
            <DatePicker showTime />
          </Form.Item>
          <Form.Item
            name="eventId"
            label="Event ID"
            rules={[{ required: true }]}
          >
            <Input />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Add Schedule
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </PageLayout>
  )
}
