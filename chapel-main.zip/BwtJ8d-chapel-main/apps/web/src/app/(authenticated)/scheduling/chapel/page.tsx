'use client'

import React, { useEffect, useState } from 'react'
import {
  Button,
  Table,
  Typography,
  Modal,
  Form,
  Input,
  DatePicker,
  Select,
} from 'antd'
import { PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ChapelUsageSchedulePage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const [events, setEvents] = useState([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [form] = Form.useForm()

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const eventsFound = await Api.Event.findManyByLocationId('chapelId', {
          includes: ['location', 'schedules'],
        })
        setEvents(eventsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch events', { variant: 'error' })
      }
    }

    fetchEvents()
  }, [])

  const handleAddEvent = async values => {
    try {
      const newEvent = await Api.Event.createOneByLocationId('chapelId', {
        ...values,
        startTime: values.timeRange[0].toISOString(),
        endTime: values.timeRange[1].toISOString(),
      })
      setEvents([...events, newEvent])
      enqueueSnackbar('Event added successfully', { variant: 'success' })
      setIsModalVisible(false)
      form.resetFields()
    } catch (error) {
      enqueueSnackbar('Failed to add event', { variant: 'error' })
    }
  }

  const columns = [
    {
      title: 'Title',
      dataIndex: 'title',
      key: 'title',
    },
    {
      title: 'Start Time',
      dataIndex: 'startTime',
      key: 'startTime',
      render: text => dayjs(text).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'End Time',
      dataIndex: 'endTime',
      key: 'endTime',
      render: text => dayjs(text).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Button onClick={() => handleDeleteEvent(record.id)}>Delete</Button>
      ),
    },
  ]

  const handleDeleteEvent = async eventId => {
    try {
      await Api.Event.deleteOne(eventId)
      setEvents(events.filter(event => event.id !== eventId))
      enqueueSnackbar('Event deleted successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to delete event', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="full-width">
      <Title>Chapel Usage Schedule</Title>
      <Text>
        Manage the scheduling of the chapel for various activities such as
        services, weddings, and other church-related events.
      </Text>
      <Button
        type="primary"
        icon={<PlusOutlined />}
        onClick={() => setIsModalVisible(true)}
      >
        Add Event
      </Button>
      <Table dataSource={events} columns={columns} rowKey="id" />

      <Modal
        title="Add New Event"
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
      >
        <Form form={form} onFinish={handleAddEvent} layout="vertical">
          <Form.Item
            name="title"
            label="Event Title"
            rules={[{ required: true }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="timeRange"
            label="Time Range"
            rules={[{ required: true }]}
          >
            <DatePicker.RangePicker showTime />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </PageLayout>
  )
}
