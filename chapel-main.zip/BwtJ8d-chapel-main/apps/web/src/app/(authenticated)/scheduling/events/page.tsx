'use client'

import React, { useEffect, useState } from 'react'
import {
  Button,
  Form,
  Input,
  DatePicker,
  Select,
  Typography,
  Table,
  Space,
  Modal,
} from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function SpecialEventsSchedulingPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [events, setEvents] = useState<Model.Event[]>([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [currentEvent, setCurrentEvent] = useState<Partial<Model.Event> | null>(
    null,
  )
  const [form] = Form.useForm()

  useEffect(() => {
    fetchEvents()
  }, [])

  const fetchEvents = async () => {
    try {
      const eventsFound = await Api.Event.findMany({ includes: ['location'] })
      setEvents(eventsFound)
    } catch (error) {
      enqueueSnackbar('Failed to fetch events', { variant: 'error' })
    }
  }

  const handleAddEvent = () => {
    setCurrentEvent(null)
    setIsModalVisible(true)
    form.resetFields()
  }

  const handleEditEvent = (event: Model.Event) => {
    setCurrentEvent(event)
    setIsModalVisible(true)
    form.setFieldsValue({
      ...event,
      startTime: dayjs(event.startTime),
      endTime: dayjs(event.endTime),
    })
  }

  const handleDeleteEvent = async (eventId: string) => {
    try {
      await Api.Event.deleteOne(eventId)
      fetchEvents()
      enqueueSnackbar('Event deleted successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to delete event', { variant: 'error' })
    }
  }

  const handleFormSubmit = async (values: any) => {
    const formattedValues = {
      ...values,
      startTime: values.startTime.toISOString(),
      endTime: values.endTime.toISOString(),
    }

    try {
      if (currentEvent?.id) {
        await Api.Event.updateOne(currentEvent.id, formattedValues)
        enqueueSnackbar('Event updated successfully', { variant: 'success' })
      } else {
        await Api.Event.createOneByLocationId('1', formattedValues) // Assuming '1' is a valid locationId
        enqueueSnackbar('Event created successfully', { variant: 'success' })
      }
      fetchEvents()
      setIsModalVisible(false)
    } catch (error) {
      enqueueSnackbar('Failed to save event', { variant: 'error' })
    }
  }

  const columns = [
    {
      title: 'Title',
      dataIndex: 'title',
      key: 'title',
    },
    {
      title: 'Start Time',
      dataIndex: 'startTime',
      key: 'startTime',
      render: (text: string) => dayjs(text).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'End Time',
      dataIndex: 'endTime',
      key: 'endTime',
      render: (text: string) => dayjs(text).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: 'Location',
      dataIndex: ['location', 'name'],
      key: 'location',
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: Model.Event) => (
        <Space size="middle">
          <Button
            icon={<EditOutlined />}
            onClick={() => handleEditEvent(record)}
          >
            Edit
          </Button>
          <Button
            icon={<DeleteOutlined />}
            onClick={() => handleDeleteEvent(record.id)}
          >
            Delete
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="full-width">
      <Title>Special Events Scheduling</Title>
      <Text>
        Manage and schedule special events such as weddings, baptisms, and other
        significant gatherings within the church community.
      </Text>
      <Button type="primary" icon={<PlusOutlined />} onClick={handleAddEvent}>
        Add Event
      </Button>
      <Table columns={columns} dataSource={events} rowKey="id" />

      <Modal
        title={currentEvent ? 'Edit Event' : 'Add Event'}
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
      >
        <Form form={form} onFinish={handleFormSubmit} layout="vertical">
          <Form.Item
            name="title"
            label="Title"
            rules={[{ required: true, message: 'Please input the title!' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item name="description" label="Description">
            <Input.TextArea />
          </Form.Item>
          <Form.Item
            name="startTime"
            label="Start Time"
            rules={[
              { required: true, message: 'Please select the start time!' },
            ]}
          >
            <DatePicker showTime />
          </Form.Item>
          <Form.Item
            name="endTime"
            label="End Time"
            rules={[{ required: true, message: 'Please select the end time!' }]}
          >
            <DatePicker showTime />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </PageLayout>
  )
}
